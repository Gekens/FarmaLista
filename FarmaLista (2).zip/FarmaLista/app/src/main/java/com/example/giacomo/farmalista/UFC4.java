package com.example.giacomo.farmalista;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Giacomo on 18/05/2016.
 */

public class UFC4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ufc4);
    }
}

