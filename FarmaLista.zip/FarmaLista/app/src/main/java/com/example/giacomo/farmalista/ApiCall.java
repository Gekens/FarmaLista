package com.example.giacomo.farmalista;

/**
 * Created by Utente on 18/05/2016.
 */
public class ApiCall {
    public static String credenziali;
    public static String medicine;
    public static String contatti;
}
